<?php $__env->startComponent('mail::message'); ?>
# Yikifree votre nouvelle plateforme de freelance

    Bonjour <?php echo e($V_postulant->postulant_nom); ?>! Vous avez postuler au projet <?php echo e($V_postulant->titre_projet); ?> sur yikifree.com.

    Veillez envoyer votre Offre technique et financière au mail suivant: # <?php echo e($V_postulant->email_client); ?>.

Cordialement,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Sawadogo-Yiki\Desktop\Freelance\back-end\resources\views/emails/Email_Postulant.blade.php ENDPATH**/ ?>