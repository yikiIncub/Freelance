<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CampagneController extends Controller
{
    public function createcampagne()
    {
        
    }
}
