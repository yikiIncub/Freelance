<?php echo e($slot); ?>

<?php /**PATH D:\Projets\Freelance\back-end\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>