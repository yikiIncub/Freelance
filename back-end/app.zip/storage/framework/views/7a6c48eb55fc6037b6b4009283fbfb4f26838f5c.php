<?php $__env->startComponent('mail::message'); ?>
# Yikifree

<?php $__env->startComponent('mail::panel'); ?>
<?php echo e($message); ?>

<?php echo $__env->renderComponent(); ?>

Cordialement,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\Projets\Freelance\back-end\resources\views/reponsemail.blade.php ENDPATH**/ ?>