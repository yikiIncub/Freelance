@component('mail::message')
# Introduction




Thanks,<br>
{{ config('app.name') }}
@endcomponent
