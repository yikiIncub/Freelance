<div>
    <h1>Merci pour votre disponiblité</h1>
</div><?php /**PATH C:\Users\Sawadogo-Yiki\Desktop\Freelance\back-end\resources\views/free.blade.php ENDPATH**/ ?>