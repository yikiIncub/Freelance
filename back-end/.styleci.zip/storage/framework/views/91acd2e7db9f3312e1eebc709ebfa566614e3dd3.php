[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Users\Sawadogo-Yiki\Desktop\Freelance\back-end\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>