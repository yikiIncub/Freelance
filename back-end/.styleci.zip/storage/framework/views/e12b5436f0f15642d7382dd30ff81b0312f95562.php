<?php $__env->startComponent('mail::message'); ?>
# Bonjour !
- <?php echo e($nom); ?> <?php echo e($numero); ?><br>
- <?php echo e($email); ?>

<?php $__env->startComponent('mail::panel'); ?>
<?php echo e($message); ?>

<?php echo $__env->renderComponent(); ?>

Cordialement,,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Sawadogo-Yiki\Desktop\Freelance\back-end\resources\views/email.blade.php ENDPATH**/ ?>