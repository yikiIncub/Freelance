<?php echo e($slot); ?>

<?php /**PATH C:\Users\Sawadogo-Yiki\Desktop\Freelance\back-end\resources\views/vendor/mail/text/panel.blade.php ENDPATH**/ ?>