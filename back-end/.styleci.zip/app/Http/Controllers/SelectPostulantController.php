<?php

namespace App\Http\Controllers;

use \Illuminate\Http\Request;

class SelectPostulantController extends Controller
{
    public function validerProstulant()
    {
        
    }
}
