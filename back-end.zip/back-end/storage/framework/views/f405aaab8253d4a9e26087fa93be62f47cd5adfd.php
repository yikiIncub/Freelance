<?php echo e($slot); ?>

<?php /**PATH C:\Users\Sawadogo-Yiki\Desktop\Freelance\back-end\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>